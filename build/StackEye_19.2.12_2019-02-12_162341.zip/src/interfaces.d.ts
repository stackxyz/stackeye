interface Window { SW: any; }
